<?php

namespace App\Filament\Resources;

use App\Filament\Resources\CourseResource\Pages;
use App\Models\Course;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class CourseResource extends Resource
{
    protected static ?string $model = Course::class;

    protected static ?string $navigationIcon = 'heroicon-o-academic-cap';

    protected static ?string $navigationLabel = 'Courses';

    protected static ?string $modelLabel = 'Course';

    protected static ?string $pluralModelLabel = 'Courses';

    protected static ?int $navigationSort = 3;

    protected static ?string $navigationGroup = 'Course Management';

    // Read-only for admins - no create/edit pages
    public static function canCreate(): bool
    {
        return false;
    }

    public static function canEdit($record): bool
    {
        return true; // Allow editing of bootcamp fields
    }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('Course Information')
                    ->schema([
                        Forms\Components\Select::make('instructor_id')
                            ->relationship('instructor', 'name')
                            ->disabled()
                            ->required(),
                        Forms\Components\Select::make('category_id')
                            ->relationship('category', 'name')
                            ->disabled()
                            ->required(),
                        Forms\Components\TextInput::make('title')
                            ->disabled()
                            ->required()
                            ->maxLength(255)
                            ->columnSpanFull(),
                        Forms\Components\Textarea::make('description')
                            ->disabled()
                            ->required()
                            ->columnSpanFull()
                            ->rows(4),
                        Forms\Components\TextInput::make('price')
                            ->disabled()
                            ->numeric()
                            ->prefix('৳'),
                        Forms\Components\TextInput::make('thumbnail_url')
                            ->disabled()
                            ->maxLength(255)
                            ->url(),
                        Forms\Components\Toggle::make('is_published')
                            ->disabled()
                            ->required(),
                        Forms\Components\TextInput::make('slug')
                            ->disabled()
                            ->required()
                            ->maxLength(255),
                    ])
                    ->columns(2),
                Forms\Components\Section::make('Bootcamp Settings')
                    ->schema([
                        Forms\Components\Toggle::make('is_bootcamp')
                            ->label('Enable Bootcamp')
                            ->helperText('Enable this to treat the course as a bootcamp')
                            ->reactive()
                            ->required(),
                        Forms\Components\FileUpload::make('bootcamp_feature_image')
                            ->label('Bootcamp Feature Image')
                            ->helperText('Upload a feature image that will be displayed on the home page')
                            ->image()
                            ->directory('bootcamp-features')
                            ->visibility('public')
                            ->required()
                            ->visible(fn (callable $get) => $get('is_bootcamp')),
                        Forms\Components\Toggle::make('show_on_homepage')
                            ->label('Show on Homepage')
                            ->helperText('If enabled, this bootcamp will be displayed on the home page')
                            ->visible(fn (callable $get) => $get('is_bootcamp'))
                            ->required(),
                    ])
                    ->columns(1),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\ImageColumn::make('thumbnail_url')
                    ->label('Thumbnail')
                    ->circular()
                    ->defaultImageUrl(url('/images/placeholder-course.png'))
                    ->size(60),
                Tables\Columns\TextColumn::make('title')
                    ->searchable()
                    ->sortable()
                    ->label('Title')
                    ->weight('bold')
                    ->description(fn ($record): string => $record->category?->name ?? 'N/A')
                    ->wrap(),
                Tables\Columns\IconColumn::make('is_bootcamp')
                    ->label('Bootcamp')
                    ->boolean()
                    ->trueIcon('heroicon-o-fire')
                    ->falseIcon('heroicon-o-x-circle')
                    ->trueColor('danger')
                    ->falseColor('gray')
                    ->sortable(),
                Tables\Columns\TextColumn::make('instructor_id')
                    ->label('Instructor')
                    ->formatStateUsing(fn ($state, $record): string => $record->instructor?->name ?? 'N/A')
                    ->searchable()
                    ->sortable()
                    ->badge()
                    ->color('warning'),
                Tables\Columns\TextColumn::make('price')
                    ->label('Price')
                    ->sortable()
                    ->formatStateUsing(fn ($state): string => $state && floatval($state) > 0 ? '৳' . number_format(floatval($state)) : 'Free')
                    ->badge()
                    ->color(fn ($state): string => $state && floatval($state) > 0 ? 'success' : 'primary'),
                Tables\Columns\IconColumn::make('is_published')
                    ->label('Status')
                    ->boolean()
                    ->trueIcon('heroicon-o-check-circle')
                    ->falseIcon('heroicon-o-x-circle')
                    ->trueColor('success')
                    ->falseColor('danger')
                    ->sortable(),
                Tables\Columns\IconColumn::make('show_on_homepage')
                    ->label('Homepage')
                    ->boolean()
                    ->trueIcon('heroicon-o-home')
                    ->falseIcon('heroicon-o-x-circle')
                    ->trueColor('success')
                    ->falseColor('gray')
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('enrollments_count')
                    ->label('Students')
                    ->sortable()
                    ->formatStateUsing(fn ($state): string => (string) ($state ?? 0))
                    ->badge()
                    ->color('info'),
                Tables\Columns\TextColumn::make('reviews_avg_rating')
                    ->label('Rating')
                    ->sortable()
                    ->badge()
                    ->color('warning')
                    ->formatStateUsing(fn ($state): string => $state && floatval($state) > 0
                        ? number_format(floatval($state), 1) . ' ★'
                        : 'N/A')
                    ->default('N/A'),
                Tables\Columns\TextColumn::make('created_at')
                    ->dateTime('M j, Y')
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->defaultSort('created_at', 'desc')
            ->filters([
                Tables\Filters\SelectFilter::make('category_id')
                    ->label('Category')
                    ->relationship('category', 'name')
                    ->searchable()
                    ->preload(),
                Tables\Filters\TernaryFilter::make('is_published')
                    ->label('Published Status')
                    ->placeholder('All courses')
                    ->trueLabel('Published only')
                    ->falseLabel('Drafts only'),
                Tables\Filters\TernaryFilter::make('is_bootcamp')
                    ->label('Bootcamp')
                    ->placeholder('All courses')
                    ->trueLabel('Bootcamps only')
                    ->falseLabel('Regular courses only'),
                Tables\Filters\SelectFilter::make('price_type')
                    ->label('Price Type')
                    ->options([
                        'free' => 'Free',
                        'paid' => 'Paid',
                    ])
                    ->query(fn (Builder $query, array $data) => $query
                        ->when(isset($data['value']) && $data['value'] === 'free', fn ($q) => $q->where(function($q) {
                            $q->whereNull('price')->orWhere('price', 0);
                        }))
                        ->when(isset($data['value']) && $data['value'] === 'paid', fn ($q) => $q->whereNotNull('price')->where('price', '>', 0))
                    ),
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\Action::make('unpublish')
                    ->label('Unpublish')
                    ->icon('heroicon-o-x-circle')
                    ->color('danger')
                    ->requiresConfirmation()
                    ->visible(fn ($record): bool => $record->is_published ?? false)
                    ->action(function ($record) {
                        $record->update(['is_published' => false]);
                        \Filament\Notifications\Notification::make()
                            ->title('Course Unpublished')
                            ->body('The course has been unpublished successfully.')
                            ->success()
                            ->send();
                    }),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\BulkAction::make('unpublish')
                        ->label('Unpublish Selected')
                        ->icon('heroicon-o-x-circle')
                        ->color('danger')
                        ->requiresConfirmation()
                        ->action(function ($records) {
                            foreach ($records as $record) {
                                $record->update(['is_published' => false]);
                            }
                            \Filament\Notifications\Notification::make()
                                ->title('Courses Unpublished')
                                ->body('The selected courses have been unpublished.')
                                ->success()
                                ->send();
                        }),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListCourses::route('/'),
            'view' => Pages\ViewCourse::route('/{record}'),
        ];
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->with(['category', 'instructor'])
            ->withAvg('reviews', 'rating')
            ->withCount('enrollments');
    }
}
