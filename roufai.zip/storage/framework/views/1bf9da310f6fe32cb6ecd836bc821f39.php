<?php $__env->startSection('title', 'আব্দুর রউফ - বাংলাদেশের সেরা AI ক্রিয়েটিভ ট্রেনিং প্ল্যাটফর্ম | AI কোর্স ও বুটক্যাম্প'); ?>
<?php $__env->startSection('description', 'AI দিয়ে ইমেজ, ভিডিও, মিউজিক ও ভয়েস তৈরি শিখুন। বিগিনার থেকে অ্যাডভান্সড লেভেল, লাইভ ক্লাস এবং রিয়েল প্রজেক্ট সহ কমপ্লিট কোর্স। আজই শুরু করুন!'); ?>
<?php $__env->startSection('keywords', 'AI কোর্স, AI ট্রেনিং, আব্দুর রউফ, Midjourney কোর্স, AI ভিডিও এডিটিং, AI মিউজিক জেনারেশন, ChatGPT কোর্স, AI টুলস বাংলাদেশ'); ?>

<?php $__env->startSection('content'); ?>

<!-- hero ellipse -->
<img src="<?php echo e(asset('website-images/hero-ellipse.svg')); ?>" alt="ellipse"
    class="absolute left-0 top-0 lg:object-contain lg:h-auto">
<!-- hero ellipse -->

<!-- hero slider section start -->
<section class="w-full relative overflow-hidden" style="height: 100vh;">

    <!-- Include Header -->
<?php echo $__env->make('website.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="absolute inset-0 w-full h-full bg-[#000]/50">
    <!-- Hero Slider -->
    <div class="hero-slider relative w-full h-full">

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $heroSlides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Slide <?php echo e($index + 1); ?> -->
        <div class="hero-slide <?php echo e($index === 0 ? 'active' : ''); ?> absolute inset-0 w-full h-full" style="opacity: <?php echo e($index === 0 ? '1' : '0'); ?>; z-index: <?php echo e($index === 0 ? '10' : '0'); ?>;">
            <div class="absolute inset-0 w-full h-full">
                <img src="<?php echo e(asset('website-images/' . $slide->background_image)); ?>" alt="<?php echo e($slide->title); ?>" class="w-full h-full object-cover">
                <div class="absolute inset-0 bg-[#000]/50"></div>
                <div class="absolute inset-0 bg-gradient-to-r from-black/90 via-black/70 to-black/30"></div>
            </div>
            <div class="container-x relative h-full flex items-center">
                <div class="max-w-2xl py-20 md:py-28 lg:py-32">
                    <h1
                        class="font-bold text-3xl md:text-4xl lg:text-5xl xl:text-6xl text-[#E2E8F0] leading-[120%] mb-4 lg:mb-6">
                        <?php echo e($slide->title); ?>

                    </h1>
                    <p class="font-normal text-base md:text-lg lg:text-xl text-[#ABABAB] leading-[140%] mb-6 lg:mb-8">
                        <?php echo e($slide->description); ?>

                    </p>
                    <a href="<?php echo e($slide->button_url ?: route('courses')); ?>"
                        class="inline-flex font-golos justify-center items-center bg-submit border border-[#9F93A7]/70 hover:!bg-lime rounded-md lg:rounded-[10px] p-1.5 font-medium text-sm md:text-base lg:text-lg text-[#fff] gap-x-3 anim hover:text-primary group lg:py-3 lg:px-6">
                        <?php echo e($slide->button_text); ?>

                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <!-- Slider Controls -->
        <div class="absolute bottom-8 left-0 right-0 z-50">
            <div class="container-x">
                <div class="flex items-center justify-between">
                    <!-- Navigation Dots -->
                    <div class="flex gap-3">
                        <button
                            class="slider-dot active w-3 h-3 rounded-full bg-[#E850FF] transition-all duration-300"
                            data-slide="0"></button>
                        <button
                            class="slider-dot w-3 h-3 rounded-full bg-[#fff]/30 hover:bg-[#fff]/50 transition-all duration-300"
                            data-slide="1"></button>
                        <button
                            class="slider-dot w-3 h-3 rounded-full bg-[#fff]/30 hover:bg-[#fff]/50 transition-all duration-300"
                            data-slide="2"></button>
                    </div>
                    <!-- Arrow Navigation -->
                    <div class="flex gap-3">
                        <button
                            class="slider-prev cursor-pointer w-10 h-10 lg:w-12 lg:h-12 rounded-full bg-[#fff]/10 hover:bg-[#E850FF] border border-[#fff]/20 flex items-center justify-center transition-all duration-300 group">
                            <svg class="w-5 h-5 text-[#fff] transform rotate-180" fill="none" stroke="currentColor"
                                viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                            </svg>
                        </button>
                        <button
                            class="slider-next cursor-pointer w-10 h-10 lg:w-12 lg:h-12 rounded-full bg-[#fff]/10 hover:bg-[#E850FF] border border-[#fff]/20 flex items-center justify-center transition-all duration-300 group">
                            <svg class="w-5 h-5 text-[#fff]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bottom Gradient Mask for smooth transition -->
        <div
            class="absolute bottom-0 left-0 right-0 h-48 md:h-64 lg:h-80 bg-gradient-to-t from-[#0a0a0a] via-[#000]/50 to-transparent z-40 pointer-events-none">
        </div>
    </div>
    </div>
</section>
<!-- hero slider section end -->

<!-- feature section start -->
<section class="w-full py-10 lg:py-20">
    <div class="container-x">
        <div class="text-center mb-10 md:mb-16 lg:mb-20">
            <h6
                class="inline-flex items-center gap-x-3 bg-[#fff]/10 rounded-md lg:rounded-[10px] py-2 px-3 lg:py-2.5 lg:px-4 font-normal text-sm lg:text-lg text-[#E2E8F0]">
                <span class="block h-[2px] w-5 bg-line"></span>
                আপনার আইডিয়াকে বদলে দিন

                <span class="block h-[2px] w-5 bg-line-2"></span>
            </h6>
            <h2 class="font-bold text-2xl md:text-4xl lg:text-[44px] text-[#E2E8F0] mt-5 lg:mt-[30px]">
               আপনার আইডিয়াকে বদলে দিন  <span class="text-gradient">এআই ক্রিয়েশনে</span>
            </h2>
            <p
                class="font-normal text-sm md:text-base lg:text-xl text-[#ABABAB] leading-[140%] mt-2 lg:mt-3.5 lg:max-w-[60%] lg:mx-auto">
                শিখুন কীভাবে আকর্ষণীয় ইমেজ, এনগেজিং ভিডিও ও প্রফেশনাল মিউজিক/ভয়েসওভার তৈরি করা যায় মুহূর্তেই।
            </p>
        </div>

        <!-- feat card -->
        <div class="w-full grid grid-cols-1 gap-y-5 md:grid-cols-2 gap-5 lg:grid-cols-3 lg:gap-x-6 ">
            <div class="w-full rounded-md lg:rounded-[20px] p-5 md:p-7 lg:p-[34px] border border-[#232323] relative">
                <img src="<?php echo e(asset('website-images/feat-card.svg')); ?>" alt="feat card"
                    class="w-full h-full absolute left-0 top-0 rounded-md lg:rounded-[20px] object-cover">

                <div
                    class="w-[100px] h-[100px] lg:w-[166px] lg:h-[160px] border-2 lg:border-[20px] border-[#21253B] rounded-full mx-auto bg-[#0A0C19] flex justify-center relative items-center">
                    <div
                        class="bg-[#000] w-20 h-20 lg:w-[100px] lg:h-[100px] rounded-full border-3 border-[#171A2C] lg:border-[12px] flex justify-center items-center">
                        <img src="<?php echo e(asset('website-images/icons/b-camp-01.svg')); ?>" alt="icons" class="w-6 md:w-8 lg:w-10">
                        <img src="<?php echo e(asset('website-images/icons/curve.svg')); ?>" alt="curve 1" class="w-[86%] absolute left-1 top-4">
                    </div>
                </div>

                <div class="mt-10 lg:mt-[60px]">
                    <h5 class="font-semibold text-sm lg:text-lg leading-[140%] text-[#E2E8F0] mb-2 lg:mb-2.5">
                       এআই ইমেজ জেনারেশন ও প্রম্পটিং care

                    </h5>
                    <p class="font-normal text-xs lg:text-sm leading-[140%] text-[#ABABAB] lg:max-w-[85%]">
                       টেক্সট প্রম্পট থেকে ভিজ্যুয়াল, পোস্টার, ক্যারেক্টার ডিজাইন ও ফেস এডিট শিখুন।</p>
                </div>
            </div>
             <div class="w-full rounded-md lg:rounded-[20px] p-5 md:p-7 lg:p-[34px] border border-[#232323] relative">
                <img src="<?php echo e(asset('website-images/feat-card.svg')); ?>" alt="feat card"
                    class="w-full h-full absolute left-0 top-0 rounded-md lg:rounded-[20px] object-cover">

                <div
                    class="w-[100px] h-[100px] lg:w-[166px] lg:h-[160px] border-2 lg:border-[20px] border-[#21253B] rounded-full mx-auto bg-[#0A0C19] flex justify-center relative items-center">
                    <div
                        class="bg-[#000] w-20 h-20 lg:w-[100px] lg:h-[100px] rounded-full border-3 border-[#171A2C] lg:border-[12px] flex justify-center items-center">
                        <img src="<?php echo e(asset('website-images/icons/b-camp-01.svg')); ?>" alt="icons" class="w-6 md:w-8 lg:w-10">
                        <img src="<?php echo e(asset('website-images/icons/curve.svg')); ?>" alt="curve 1" class="w-[86%] absolute left-1 top-4">
                    </div>
                </div>

                <div class="mt-10 lg:mt-[60px]">
                    <h5 class="font-semibold text-sm lg:text-lg leading-[140%] text-[#E2E8F0] mb-2 lg:mb-2.5">
                      এআই ভিডিও ক্রিয়েশন


                    </h5>
                    <p class="font-normal text-xs lg:text-sm leading-[140%] text-[#ABABAB] lg:max-w-[85%]">
                     টেক্সট/ইমেজ থেকে ভিডিও, লিপ-সিঙ্ক, ভয়েস ও ইফেক্টসহ বিজ্ঞাপন ও শর্টস তৈরি করুন।

</p>
                </div>
            </div>
             <div class="w-full rounded-md lg:rounded-[20px] p-5 md:p-7 lg:p-[34px] border border-[#232323] relative">
                <img src="<?php echo e(asset('website-images/feat-card.svg')); ?>" alt="feat card"
                    class="w-full h-full absolute left-0 top-0 rounded-md lg:rounded-[20px] object-cover">

                <div
                    class="w-[100px] h-[100px] lg:w-[166px] lg:h-[160px] border-2 lg:border-[20px] border-[#21253B] rounded-full mx-auto bg-[#0A0C19] flex justify-center relative items-center">
                    <div
                        class="bg-[#000] w-20 h-20 lg:w-[100px] lg:h-[100px] rounded-full border-3 border-[#171A2C] lg:border-[12px] flex justify-center items-center">
                        <img src="<?php echo e(asset('website-images/icons/b-camp-01.svg')); ?>" alt="icons" class="w-6 md:w-8 lg:w-10">
                        <img src="<?php echo e(asset('website-images/icons/curve.svg')); ?>" alt="curve 1" class="w-[86%] absolute left-1 top-4">
                    </div>
                </div>

                <div class="mt-10 lg:mt-[60px]">
                    <h5 class="font-semibold text-sm lg:text-lg leading-[140%] text-[#E2E8F0] mb-2 lg:mb-2.5">
                       এআই মিউজিক ও ভয়েস জেনারেশন


                    </h5>
                    <p class="font-normal text-xs lg:text-sm leading-[140%] text-[#ABABAB] lg:max-w-[85%]">
                       এআই দিয়ে জিঙ্গেল, ব্যাকগ্রাউন্ড স্কোর, ভয়েসওভার ও সাউন্ড ইফেক্ট তৈরি করুন।</p>
                </div>
            </div>
        </div>
        <!-- feat card -->
        
    </div>
</section>
<!-- feature section end -->



<!-- border line -->
<div class="container-x">
    <img src="<?php echo e(asset('website-images/line.svg')); ?>" alt="line" class="w-full mx-auto">
</div>
<!-- border line -->

<!-- our courses section start -->
<section class="w-full py-10 lg:py-20">
    <div class="container-x">
        <div class="text-center mb-10 md:mb-16 lg:mb-20">
            <h6
                class="inline-flex items-center gap-x-2 bg-[#fff]/10 rounded-md lg:rounded-[10px] py-2 px-3 lg:py-2.5 lg:px-4 font-normal text-sm lg:text-lg text-[#E2E8F0]">
                <span class="block h-[2px] w-5 bg-line"></span>
                আমাদের কোর্স সমূহ
                <span class="block h-[2px] w-5 bg-line-2"></span>
            </h6>
            <h2 class="font-bold text-2xl md:text-4xl lg:text-[44px] text-[#E2E8F0] mt-5 lg:mt-[30px]">
                ফিউচার রেডি হতে বেছে নিন <span class="text-gradient">আপনার পছন্দের স্কিল </span></h2>
            <p
                class="font-normal text-sm md:text-base lg:text-xl text-[#ABABAB] leading-[140%] mt-2 lg:mt-3.5 lg:max-w-[65%] lg:mx-auto">
                বিগিনার থেকে অ্যাডভান্সড, প্রতিটি কোর্স সাজানো হয়েছে বর্তমান মার্কেটের চাহিদা অনুযায়ী।</p>
        </div>
        <div class="w-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-y-4 md:gap-5 lg: gap-x-6">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $featuredCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if (isset($component)) { $__componentOriginalf9cc6080c9bd6f32c9448362e9a0d649 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9cc6080c9bd6f32c9448362e9a0d649 = $attributes; } ?>
<?php $component = App\View\Components\CourseCard::resolve(['course' => $course] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('course-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\CourseCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9cc6080c9bd6f32c9448362e9a0d649)): ?>
<?php $attributes = $__attributesOriginalf9cc6080c9bd6f32c9448362e9a0d649; ?>
<?php unset($__attributesOriginalf9cc6080c9bd6f32c9448362e9a0d649); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9cc6080c9bd6f32c9448362e9a0d649)): ?>
<?php $component = $__componentOriginalf9cc6080c9bd6f32c9448362e9a0d649; ?>
<?php unset($__componentOriginalf9cc6080c9bd6f32c9448362e9a0d649); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-12 text-center py-10">
                <p class="text-[#ABABAB] text-lg">এখনো কোনো কোর্স নেই</p>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</section>
<!-- our courses section end -->

<section class="w-full py-10 lg:py-20">
    <div class="container-x">
        <!-- common title start -->
        <div class="text-center mb-10 md:mb-16 lg:mb-20">
            <h6
                class="inline-flex items-center gap-x-2 bg-[#fff]/10 rounded-md lg:rounded-[10px] py-2 px-3 lg:py-2.5 lg:px-4 font-normal text-sm lg:text-lg text-[#E2E8F0]">
                <span class="block h-[2px] w-5 bg-line"></span>
                প্রশ্ন উত্তর
                <span class="block h-[2px] w-5 bg-line-2"></span>
            </h6>
            <h2 class="font-bold text-2xl md:text-4xl lg:text-[44px] text-[#E2E8F0] mt-5 lg:mt-[30px]">
                সচরাচর জানতে চাওয়া <span class="text-gradient"> প্রশ্নের উত্তর </span></h2>
            <p
                class="font-normal text-sm md:text-base lg:text-xl text-[#ABABAB] leading-[140%] mt-2 lg:mt-3.5 lg:max-w-[65%] lg:mx-auto">
                আমাদের বুটক্যাম্প থেকে শেখা শিক্ষার্থীদের রিয়েল রিভিউ – যা আপনাকেও এগিয়ে যেতে উৎসাহ দেবে।
            </p>
        </div>
        <!-- common title end -->

        <div class="w-full grid grid-cols-1 gap-y-1 lg:gap-y-4">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div
                class="faq-item item bg-submit rounded-[10px] p-2.5 grid grid-cols-12 items-center lg:items-start gap-x-2.5 md:p-3.5 lg:p-5 border border-[#49484E] <?php echo e($index % 2 === 0 ? 'faq-card-glow' : 'faq-card-glow faq-card-glow-variant'); ?> <?php echo e($index === 0 ? 'active' : ''); ?>"
                onclick="toggleFAQ(this)">
                <div class="w-full col-span-10">
                    <h5 class="text-[#E2E8F0] font-medium text-lg md:text-xl lg:text-2xl lg:pl-5"><?php echo e($faq->question); ?></h5>

                    <p class="faq-answer text-sm text-secondary-200 lg:text-base <?php echo e($index === 0 ? 'active' : ''); ?>"><?php echo e($faq->answer); ?></p>
                </div>
                <button type="button" class="col-span-2 flex justify-end cursor-pointer">
                    <img src="<?php echo e(asset('website-images/icons/angle-down-circle.svg')); ?>" alt="angle" class="w-5 lg:w-[26px] faq-icon">
                </button>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</section>

<!-- review section start -->
<section class="w-full py-10 lg:py-20">
    <div class="container-x">
        <div class="text-center mb-10 md:mb-16 lg:mb-20">
            <h6
                class="inline-flex items-center gap-x-2 bg-[#fff]/10 rounded-md lg:rounded-[10px] py-2 px-3 lg:py-2.5 lg:px-4 font-normal text-sm lg:text-lg text-[#E2E8F0]">
                <span class="block h-[2px] w-5 bg-line"></span>
                অভিজ্ঞতা সমূহ
                <span class="block h-[2px] w-5 bg-line-2"></span>
            </h6>
            <h2 class="font-bold text-2xl md:text-4xl lg:text-[44px] text-[#E2E8F0] mt-5 lg:mt-[30px]">যারা শিখেছেন,
                <span class="text-gradient">তারাই বলছেন</span>
            </h2>
            <p
                class="font-normal text-sm md:text-base lg:text-xl text-[#ABABAB] leading-[140%] mt-2 lg:mt-3.5 lg:max-w-[50%] lg:mx-auto">
                আমাদের বুটক্যাম্প থেকে শেখা শিক্ষার্থীদের রিয়েল রিভিউ – যা আপনাকেও এগিয়ে যেতে উৎসাহ দেবে।</p>
        </div>

        <div class="w-full grid grid-cols-12 gap-y-5 gap-5 lg:gap-6">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <!-- review card -->
            <div
                class="w-full rounded-md lg:rounded-[10px] p-5 md:p-7 lg:p-[30px] border border-[#232323] relative bg-[#131620] col-span-12 md:col-span-6 lg:col-span-4 review-card">
                <!-- Quote Icon at Top -->
                <div class="absolute top-4 right-4 flex items-center justify-center w-8 h-8 lg:w-10 lg:h-10 rounded-full bg-quote p-1 anim">
                    <img src="<?php echo e(asset('website-images/icons/quote.svg')); ?>" alt="quote" class="w-4 lg:w-5">
                </div>

                <p class="font-normal text-[#ABABAB] text-xs lg:text-sm leading-[140%]">
                    <?php echo e($review->comment ?? ''); ?>

                </p>

                <hr class="border-0 w-full h-[1px] bg-[#232323] block my-5 lg:my-[30px]">

                <div class="w-full flex items-center justify-between">
                    <div class="flex items-center gap-x-3">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($review->user && $review->user->avatar): ?>
                        <img src="<?php echo e($review->user->avatar); ?>" alt="<?php echo e($review->user->name ?? 'User'); ?>"
                            class="w-10 h-10 rounded-full object-contain">
                        <?php else: ?>
                        <img src="<?php echo e(asset('website-images/user-avatar.webp')); ?>" alt="User"
                            class="w-10 h-10 rounded-full object-contain">
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <div>
                            <h5 class="font-medium text-sm text-[#E2E8F0] flex items-center gap-x-2">
                                <?php echo e($review->user?->name ?? 'Anonymous'); ?>

                            </h5>
                            <h6 class="common-para !text-xs text-secondary-200">
                                <?php echo e($review->user?->role ?? 'Student'); ?>

                            </h6>
                        </div>
                    </div>
                    <div class="flex items-center gap-x-1">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($review->rating): ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php for($i = 1; $i <= 5; $i++): ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($i <= floor($review->rating)): ?>
                                    <span class="text-lg lg:text-xl text-[#E2E8F0]">⭐</span>
                                <?php else: ?>
                                    <span class="text-lg lg:text-xl text-[#232323]">☆</span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php else: ?>
                            <span class="text-sm text-[#ABABAB]">No rating</span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            </div>
            <!-- review card -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-12 text-center py-10">
                <p class="text-[#ABABAB] text-lg">এখনো কোনো রিভিউ নেই</p>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</section>
<!-- review section end -->

<!-- border line -->
<div class="container-x">
    <img src="<?php echo e(asset('website-images/line.svg')); ?>" alt="line" class="w-full mx-auto">
</div>
<!-- border line -->

<!-- upcommin course section -->
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bootcampConfig): ?>
<section class="w-full pb-1 lg:pb-10 relative">
    <div class="container-x">
        <div class="w-full text-center mt-10 md:mt-14 lg:mt-[90px] relative z-[99]">
            <h1
                class="inline-flex items-center gap-x-3 bg-[#fff]/10 rounded-md lg:rounded-[10px] py-2 px-3 lg:py-2.5 lg:px-4 font-normal text-sm lg:text-lg text-[#E2E8F0]">
                <span class="block h-[2px] w-5 bg-line"></span>
                আপকামিং লাইভ বুটক্যাম্প
                <span class="block h-[2px] w-5 bg-line-2"></span>
            </h1>
            <h2 class="font-bold text-2xl md:text-4xl lg:text-[44px] text-[#E2E8F0] mt-5 lg:mt-[30px]">
                <?php echo $bootcampConfig->title; ?>

            </h2>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bootcampConfig->description): ?>
            <p
                class="font-normal text-sm md:text-base lg:text-xl text-[#ABABAB] leading-[140%] mt-2 lg:mt-3.5 lg:max-w-[60%] lg:mx-auto">
                <?php echo $bootcampConfig->description; ?>

            </p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <!-- Countdown Timer -->
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bootcampConfig->countdown_target_date): ?>
            <div class="flex justify-center gap-x-3 lg:gap-x-5 items-center mt-5 md:mt-10 lg:mt-11">
                <div
                    class="inline-flex font-golos justify-center items-center bg-submit border border-[#9F93A7]/70 rounded-md lg:rounded-[10px] p-1.5 font-medium text-sm text-[#fff] gap-x-3 anim md:text-base px-3 lg:text-lg lg:py-3 lg:px-5"
                    id="countdown-timer">
                    <span id="countdown-days">00</span> Days :
                    <span id="countdown-hours">00</span> Hours :
                    <span id="countdown-minutes">00</span> Minutes :
                    <span id="countdown-seconds">00</span> Seconds
                </div>
            </div>
            <script>
                (function() {
                    // Debug: Show what date we're using
                    const targetDateStr = '<?php echo e($bootcampConfig->countdown_target_date->format('Y-m-d H:i:s')); ?>';
                    console.log('📅 Countdown Target Date:', targetDateStr);

                    const targetDate = new Date(targetDateStr).getTime();
                    const now = new Date().getTime();

                    console.log('🎯 Target Date (Object):', new Date(targetDate));
                    console.log('📅 Current Date:', new Date(now));
                    console.log('⏰ Difference (hours):', ((targetDate - now) / (1000 * 60 * 60)).toFixed(2));

                    const daysEl = document.getElementById('countdown-days');
                    const hoursEl = document.getElementById('countdown-hours');
                    const minutesEl = document.getElementById('countdown-minutes');
                    const secondsEl = document.getElementById('countdown-seconds');

                    function update() {
                        const currentTime = new Date().getTime();
                        const diff = targetDate - currentTime;

                        if (diff < 0) {
                            document.getElementById('countdown-timer').innerHTML = 'কোর্স শুরু হয়ে গেছে!';
                            return;
                        }

                        const d = Math.floor(diff / (1000 * 60 * 60 * 24));
                        const h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                        const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                        const s = Math.floor((diff % (1000 * 60)) / 1000);

                        daysEl.textContent = String(d).padStart(2, '0');
                        hoursEl.textContent = String(h).padStart(2, '0');
                        minutesEl.textContent = String(m).padStart(2, '0');
                        secondsEl.textContent = String(s).padStart(2, '0');
                    }

                    update();
                    setInterval(update, 1000);
                })();
            </script>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


        </div>
        <div class="w-full mt-8 md:mt-12 lg:mt-[62px] lg:max-w-[80%] mx-auto">
            <!-- bootcamp thumbnail -->
            <div
                class="w-full bg-[#131620] border border-[#232323] p-3 lg:p-5 rounded-md lg:rounded-[20px]">
                <div class="w-full relative" id="video-player"
                    data-video-url="<?php echo e($bootcampConfig->display_video_url ?? ''); ?>">
                    <img src="<?php echo e(!empty($bootcampConfig->thumbnail_image) ? (strpos($bootcampConfig->thumbnail_image, 'http') === 0 ? $bootcampConfig->thumbnail_image : Storage::url($bootcampConfig->thumbnail_image)) : ($bootcampConfig->course && $bootcampConfig->course->thumbnail_url ? $bootcampConfig->course->thumbnail_url : asset('website-images/speaking-person.webp'))); ?>"
                    alt="bootcamp thumbnail"
                    class="w-full h-[349px] object-cover rounded-md lg:rounded-[10px] lg:h-[700px]">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($bootcampConfig->display_video_url)): ?>
                    <div class="absolute left-0 top-0 w-full h-full flex items-center justify-center">
                        <button type="button" id="play-video-button"
                            class="w-12 h-12 lg:w-20 lg:h-20 rounded-full bg-[#fff]/40 flex items-center justify-center p-1 cursor-pointer animate-pulse anim">
                            <img src="<?php echo e(asset('website-images/icons/play.svg')); ?>" alt="play" class="w-4 lg:w-6">
                        </button>
                    </div>
                    <script>
                        (function() {
                            const btn = document.getElementById('play-video-button');
                            if (btn) {
                                btn.onclick = function(e) {
                                    e.preventDefault();
                                    const videoPlayer = document.getElementById('video-player');
                                    const videoUrl = videoPlayer.getAttribute('data-video-url');

                                    let videoId = '';
                                    if (videoUrl.includes('youtube.com/watch?v=')) {
                                        videoId = videoUrl.split('v=')[1].split('&')[0];
                                    } else if (videoUrl.includes('youtu.be/')) {
                                        videoId = videoUrl.split('youtu.be/')[1].split('?')[0];
                                    }

                                    if (videoId) {
                                        videoPlayer.innerHTML = '<iframe width="100%" height="700px" src="https://www.youtube.com/embed/' + videoId + '?autoplay=1" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';
                                    }
                                };
                            }
                        })();
                    </script>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <!-- video box -->
            </div>
        </div>
    </div>
</section>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<!-- payment section start -->
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bootcampConfig): ?>
<section class="w-full py-10 lg:py-20">
    <div class="container-x">
        <div
            class="w-full bg-submit rounded-[10px] py-5 px-6 flex flex-col lg:flex-row justify-center items-center text-center lg:justify-between border border-[#49484E]/50">
            <div class="lg:text-start">
                <h5 class="font-medium text-lg white-70 lg:text-2xl"><?php echo $bootcampConfig->bootcamp_name ?? ($bootcampConfig->course ? $bootcampConfig->course->title : 'বুটক্যাম্প'); ?></h5>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bootcampConfig->start_date && $bootcampConfig->end_date): ?>
                <p class="font-medium text-sm text-[#ABABAB] mt-1 lg:text-base">
                    <?php echo e($bootcampConfig->start_date->format('d F')); ?> থেকে <?php echo e($bootcampConfig->end_date->format('d F Y')); ?> |
                    প্রশিক্ষক: <?php echo e($bootcampConfig->display_instructor_name); ?></p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
            <h6 class="font-medium text-base text-[#C7C7C7] mt-6 lg:text-2xl lg:mt-0">কোর্স ফি:  <span
                    class="text-orange font-bold lg:text-3xl"><?php echo $bootcampConfig->display_price; ?></span> <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bootcampConfig->display_price !== 'ফ্রি'): ?><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></h6>
        </div>

        <div
            class="w-full bg-card/80 rounded-[10px] py-5 px-4 mt-10 divide-y lg:divide-x lg:divide-y-0 divide-[#fff]/10 lg:p-10 lg:mt-12 grid grid-cols-1 lg:grid-cols-2 lg:gap-x-10 border border-[#49484E]/50">
            <div class="left pb-10 lg:pb-0">
                <h3 class="text-center font-medium text-2xl text-[#fff] lg:text-start lg:text-[32px]">এখনই সহজে
                    পেমেন্ট করুন</h3>
                <p class="font-medium text-sm text-[#ABABAB] mt-1 text-center lg:text-start lg:text-base lg:max-w-[80%]">
                    আমাদের কোর্সে ভর্তি হতে পেমেন্ট করা একেবারেই
                    সহজ। বিকাশ, নগদ বা রকেট দিয়ে পেমেন্ট করলেই সঙ্গে সঙ্গে কোর্স এক্সেস পাবেন।</p>

                <h4 class="mt-10 font-medium text-base white-70 text-center mb-2.5 lg:mt-[60px] lg:text-xl lg:text-start">
                    এই নম্বরে পেমেন্ট করুন</h4>
 
                <div
                    class="flex bg-[#011330] justify-between items-center max-w-[80%] rounded-[4px] mx-auto p-1.5 pl-4 lg:mx-0 lg:mr-auto lg:max-w-[46%] lg:rounded-lg">
                    <h5 class="font-bold text-xl text-gradient lg:text-2xl" id="phone-number-display">০১৭১২৩৪৫৬৭৮</h5>
                    <button type="button" onclick="copyPhoneNumber(); return false;"
                        class="bg-[#0B2042] rounded-[2px] py-2 px-3 font-normal text-xs text-blue lg:text-sm anim hover:bg-orange hover:text-primary cursor-pointer anim animate-pulse z-50 pointer-events-auto"
                        style="position: relative; z-index: 1000 !important; pointer-events: auto !important;">কপি
                        করুন</button>
                </div> 

                <h6 class="mt-6 font-medium white-70 text-base lg:mt-[30px] lg:text-lg">বিশেষ দ্রষ্টব্য</h6>

                <ul class="mt-2.5 flex flex-col gap-y-1">
                    <li class="flex items-center gap-x-2">
                        <span class="w-[2px] h-[2px] block bg-[#D9D9D9] lg:w-[3px] lg:h-[3px]"></span>
                        <p class="text-sm font-normal text-[#ABABAB] lg:text-base">
                            Transaction ID সংরক্ষণ করুন, ভুল নম্বরে পাঠালে দায়ভার আমাদের নয়।
                        </p>
                    </li>
                    <li class="flex items-center gap-x-2">
                        <span class="w-[2px] h-[2px] block bg-[#D9D9D9] lg:w-[3px] lg:h-[3px]"></span>
                        <p class="text-sm font-normal text-[#ABABAB] lg:text-base">
                            সফল পেমেন্টে SMS/ইমেইল পাবেন।
                        </p>
                    </li>
                    <li class="flex items-center gap-x-2">
                        <span class="w-[2px] h-[2px] block bg-[#D9D9D9] lg:w-[3px] lg:h-[3px]"></span>
                        <p class="text-sm font-normal text-[#ABABAB] lg:text-base">
                            টাকা ফেরতযোগ্য নয়, সমস্যায় <a href="#" class="text-orange underline">সাপোর্টে
                                যোগাযোগ করুন।</a>
                        </p>
                    </li>
                </ul>
            </div>
            <div class="right pt-10 lg:pt-0">
                <h5 class="font-medium text-base white-70 text-center mb-2.5 lg:text-lg lg:text-start">আপনার
                    পেমেন্ট করা মাধ্যমটি বেছে নিন</h5>

                <form id="bootcamp-enrollment-form" method="POST"
                    class="block mt-5 lg:mt-3 lg:grid lg:grid-cols-12 lg:gap-x-5">
                    <?php echo csrf_field(); ?>

                    <!-- Hidden Fields -->
                    <input type="hidden" name="bootcamp_config_id" value="<?php echo e($bootcampConfig->id); ?>">
                    <input type="hidden" name="course_id" value="<?php echo e($bootcampConfig->course_id ?? ''); ?>">
                    <div
                        class="flex w-full justify-between items-center gap-x-2 lg:gap-x-5 lg:justify-start lg:gap-x-6 lg:mb-[60px] lg:col-span-12">
                        <label for="bootcamp_nagad" class="flex items-center  bg-card anim cursor-pointer px-2 gap-x-2 w-28 h-12">
                            <input type="radio" name="payment_method" id="bootcamp_nagad" value="nagad" checked>
                            <img src="<?php echo e(asset('website-images/icons/nagad.svg')); ?>" alt="nagad" class="max-w-14 lg:max-w-20">
                        </label>
                        <label for="bootcamp_bkash" class="flex items-center  bg-card anim cursor-pointer px-2 gap-x-2 w-28 h-12">
                            <input type="radio" name="payment_method" id="bootcamp_bkash" value="bkash">
                            <img src="<?php echo e(asset('website-images/icons/bkash.svg')); ?>" alt="bkash" class="max-w-14 lg:max-w-20">
                        </label>
                        <label for="bootcamp_rocket" class="flex items-center  bg-card anim cursor-pointer px-2 gap-x-2 w-24 h-12">
                            <input type="radio" name="payment_method" id="bootcamp_rocket" value="rocket">
                            <img src="<?php echo e(asset('website-images/icons/rocket.svg')); ?>" alt="rocket" class="max-w-10 lg:max-w-12.5">
                        </label>
                    </div>
                    <div class="w-full mt-5 lg:col-span-6">
                        <label for="bootcamp_name" class="font-medium text-base white-70 block w-full mb-2.5">আপনার
                            নাম</label>
                        <input type="text" name="name" id="bootcamp_name" placeholder="নাম"
                            class="bg-[#000] h-[38px] rounded-sm px-4 w-full text-[#fff] font-medium text-base placeholder:text-gray-400"
                            required>
                    </div>
                    <div class="w-full mt-5 lg:col-span-6">
                        <label for="bootcamp_email" class="font-medium text-base white-70 block w-full mb-2.5">আপনার
                            ইমেইল</label>
                        <input type="email" name="email" id="bootcamp_email" placeholder="ইমেইল"
                            class="bg-[#000] h-[38px] rounded-sm px-4 w-full text-[#fff] font-medium text-base placeholder:text-gray-400"
                            required>
                    </div>
                    <div class="w-full mt-5 lg:col-span-6">
                        <label for="bootcamp_payment_number" class="font-medium text-base white-70 block w-full mb-2.5">আপনার
                            পেমেন্ট নম্বর</label>
                        <input type="text" name="payment_number" id="bootcamp_payment_number" placeholder="পেমেন্ট নম্বর"
                            class="bg-[#000] h-[38px] rounded-sm px-4 w-full text-[#fff] font-medium text-base placeholder:text-gray-400"
                            required>
                    </div>
                    <div class="w-full mt-5 lg:col-span-6">
                        <label for="bootcamp_paid_amount" class="font-medium text-base white-70 block w-full mb-2.5">পেমেন্ট পরিমাণ (টাকা)</label>
                        <input type="number" name="paid_amount" id="bootcamp_paid_amount" placeholder="পরিমাণ"
                            class="bg-[#000] h-[38px] rounded-sm px-4 w-full text-[#fff] font-medium text-base placeholder:text-gray-400"
                            required>
                    </div>
                    <div class="w-full mt-5 lg:col-span-6">
                        <label for="bootcamp_transaction_id" class="font-medium text-base white-70 block w-full mb-2.5">পেমেন্ট ট্রানজেকশন
                            ID</label>
                        <input type="text" name="transaction_id" id="bootcamp_transaction_id" placeholder="ট্রানজেকশন ID"
                            class="bg-[#000] h-[38px] rounded-sm px-4 w-full text-[#fff] font-medium text-base placeholder:text-gray-400"
                            required>
                    </div>

                    <div class="w-full flex justify-center lg:col-span-12 lg:justify-end">
                        <button type="button" id="submit-enrollment-btn"
                            class="bg-submit hover:!bg-lime hover:text-primary py-2 px-4 font-medium text-base white-70 mt-5 anim cursor-pointer lg:text-xl lg:py-3.5 lg:px-6 rounded-[10px]">কনফার্ম
                            করুন</button>
                    </div>

                </form>

                <!-- Message Container -->
                <div id="enrollment-message" class="hidden mt-5 p-4 rounded-lg text-center"></div>

                <script>
                    function showMessage(message, isSuccess) {
                        const messageContainer = document.getElementById('enrollment-message');
                        messageContainer.classList.remove('hidden');

                        if (isSuccess) {
                            messageContainer.className = 'mt-5 p-4 rounded-lg text-center bg-green-500/20 border border-green-500/50';
                            messageContainer.innerHTML = `
                                <div class="flex items-center justify-center gap-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                    </svg>
                                    <p class="text-green-400 font-medium text-lg">${message}</p>
                                </div>
                            `;
                        } else {
                            messageContainer.className = 'mt-5 p-4 rounded-lg text-center bg-red-500/20 border border-red-500/50';
                            messageContainer.innerHTML = `
                                <div class="flex items-center justify-center gap-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                    </svg>
                                    <p class="text-red-400 font-medium text-lg">${message}</p>
                                </div>
                            `;
                        }

                        // Auto hide after 5 seconds
                        setTimeout(() => {
                            messageContainer.classList.add('hidden');
                        }, 5000);
                    }

                    document.getElementById('submit-enrollment-btn').addEventListener('click', function(e) {
                        e.preventDefault();

                        // Hide any previous message
                        document.getElementById('enrollment-message').classList.add('hidden');

                        const form = document.getElementById('bootcamp-enrollment-form');
                        const formData = new FormData(form);
                        const submitBtn = this;

                        // Get selected payment method
                        const paymentMethod = document.querySelector('input[name="payment_method"]:checked');
                        if (!paymentMethod) {
                            showMessage('অনুগ্রহ করে পেমেন্টের মাধ্যম নির্বাচন করুন', false);
                            return;
                        }

                        // Validate required fields
                        const name = formData.get('name');
                        const email = formData.get('email');
                        const paymentNumber = formData.get('payment_number');
                        const transactionId = formData.get('transaction_id');
                        const paidAmount = formData.get('paid_amount');

                        if (!name || !email || !paymentNumber || !transactionId || !paidAmount) {
                            showMessage('অনুগ্রহ করে সকল তথ্য পূরণ করুন', false);
                            return;
                        }

                        // Disable submit button
                        submitBtn.disabled = true;
                        submitBtn.textContent = 'জমা হচ্ছে...';

                        // Convert FormData to object
                        const data = {
                            payment_method: paymentMethod.value,
                            name: name,
                            email: email,
                            payment_number: paymentNumber,
                            transaction_id: transactionId,
                            paid_amount: paidAmount,
                            course_id: formData.get('course_id') || null
                        };

                        fetch('<?php echo e(route("bootcamp.enroll")); ?>', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                            },
                            body: JSON.stringify(data)
                        })
                        .then(response => response.json())
                        .then(result => {
                            if (result.success) {
                                showMessage(result.message, true);
                                form.reset();
                                // Reset payment method selection to first option
                                document.getElementById('bootcamp_nagad').checked = true;
                            } else {
                                showMessage(result.message || 'দুঃখিত, আপনার রিকোয়েস্ট জমা দেওয়া যায়নি। অনুগ্রহ করে আবার চেষ্টা করুন।', false);
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            showMessage('দুঃখিত, একটি ত্রুটি হয়েছে। অনুগ্রহ করে পরে আবার চেষ্টা করুন।', false);
                        })
                        .finally(() => {
                            // Re-enable submit button
                            submitBtn.disabled = false;
                            submitBtn.textContent = 'কনফার্ম করুন';
                        });
                    });
                </script>
            </div>
        </div>
    </div>
</section>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<!-- payment section end -->

<!-- get start section start -->
<section class="w-full py-10 lg:py-20">
    <div class="container-x">

        <div class="text-center mb-10 md:mb-16 lg:mb-20">

            <h2 class="font-bold text-2xl md:text-4xl lg:text-[44px] text-[#E2E8F0] mt-5 lg:mt-[30px]">
                আপনার আইডিয়াকে বদলে দিন <span class="text-gradient"> এআই ক্রিয়েশনে </span></h2>
            <p
                class="font-normal text-sm md:text-base lg:text-xl text-[#ABABAB] leading-[140%] mt-2 lg:mt-3.5 lg:max-w-[65%] lg:mx-auto">
                সঠিক পদ্ধতিতে, ধাপে ধাপে এবং কৌশল ব্যবহার করে আপনার স্কিলকে দ্রুত দক্ষ করে তুলুন
            </p>
        </div>

        <div class="get-bg relative py-12 px-8 lg:py-[94px] lg:px-[220px] rounded-[20px] lg:min-h-[365px]">
            <div class="absolute left-0 bottom-0 z-20 w-full h-full flex justify-between">
                <img src="<?php echo e(asset('website-images/get-start-bottom-left.svg')); ?>" alt="get left"
                    class="rounded-bl-[20px] lg:object-contain rounded-tl-[20px] max-w-[50%]">
                <img src="<?php echo e(asset('website-images/get-start-top-right.svg')); ?>" alt="get right"
                    class="rounded-tr-[20px] rounded-br-[20px] max-w-[50%] lg:object-contain">
            </div>
            <div class="text-center relative z-30 w-full">
                <h2 class="font-bold text-2xl lg:text-[44px] text-[#fff] leading-[120%] mb-1">ক্রিয়েটিভিটির ভবিষ্যৎ
                    <span class="text-gradient">এখন আপনার হাতে</span>
                </h2>
                <p class="font-normal text-sm md:text-base lg:text-xl text-[#ABABAB] leading-[120%]">RoufAI প্ল্যাটফর্মে এখনই যুক্ত হোন, হয়ে উঠুন এআই-চালিত ক্রিয়েটিভ প্রফেশনাল।</p>

                <div class="flex justify-center items-center gap-x-4  mt-5 lg:mt-10 lg:gap-x-5">
                    <a href="<?php echo e(route('courses')); ?>"
                        class="inline-flex font-golos justify-center items-center bg-submit rounded-[10px] p-1.5 font-medium text-sm text-[#fff] gap-x-2.5 anim
               hover:!bg-lime md:text-base px-2 lg:text-lg hover:text-primary group lg:my-0 lg:order-1 border border-[#9F93A7]/70 lg:py-3 lg:px-6">
                        এখনই এনরোল করুন
                    </a>
                    <a href="<?php echo e(route('courses')); ?>"
                        class="inline-flex font-golos justify-center items-center bg-black rounded-[10px] p-1.5 font-medium text-sm text-[#fff] gap-x-2.5 anim
                 md:text-base lg:text-lg hover:text-orange px-2 group lg:my-0 lg:order-1 border border-[#9F93A7]/70 lg:py-3 lg:px-6">
                        সার্টিফিকেট পান
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- get start section end -->

<!-- border line -->
<div class="container-x">
    <img src="<?php echo e(asset('website-images/line.svg')); ?>" alt="line" class="w-full mx-auto">
</div>
<!-- border line -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<style>
    .hero-slide {
        opacity: 0 !important;
        transition: opacity 1s ease-in-out;
        pointer-events: none;
        z-index: 0;
    }
    .hero-slide.active {
        opacity: 1 !important;
        pointer-events: auto;
        z-index: 10;
    }
</style>
<script>
    console.log('🚀 Scripts loading...');

    // Hero Slider
    document.addEventListener('DOMContentLoaded', function() {
        console.log('🎠 Hero slider script loaded');

        const slides = document.querySelectorAll('.hero-slide');
        const dots = document.querySelectorAll('.slider-dot');
        const prevBtn = document.querySelector('.slider-prev');
        const nextBtn = document.querySelector('.slider-next');
        let currentSlide = 0;
        let autoPlayInterval;

        function goToSlide(index) {
            // Hide current slide
            slides[currentSlide].classList.remove('active');
            slides[currentSlide].style.opacity = '0';
            slides[currentSlide].style.zIndex = '0';

            dots[currentSlide].classList.remove('bg-[#E850FF]');
            dots[currentSlide].classList.add('bg-[#fff]/30');

            // Update current slide index
            currentSlide = index;

            // Show new slide
            slides[currentSlide].classList.add('active');
            slides[currentSlide].style.opacity = '1';
            slides[currentSlide].style.zIndex = '10';

            dots[currentSlide].classList.remove('bg-[#fff]/30');
            dots[currentSlide].classList.add('bg-[#E850FF]');

            console.log(`🎠 Slide ${currentSlide + 1} activated`);
        }

        function nextSlide() {
            const nextIndex = (currentSlide + 1) % slides.length;
            goToSlide(nextIndex);
        }

        function prevSlide() {
            const prevIndex = (currentSlide - 1 + slides.length) % slides.length;
            goToSlide(prevIndex);
        }

        function startAutoPlay() {
            autoPlayInterval = setInterval(nextSlide, 5000); // Change slide every 5 seconds
        }

        function stopAutoPlay() {
            clearInterval(autoPlayInterval);
        }

        // Dot navigation
        dots.forEach((dot, index) => {
            dot.addEventListener('click', function() {
                stopAutoPlay();
                goToSlide(index);
                startAutoPlay();
            });
        });

        // Arrow navigation
        if (prevBtn) {
            prevBtn.addEventListener('click', function() {
                stopAutoPlay();
                prevSlide();
                startAutoPlay();
            });
        }

        if (nextBtn) {
            nextBtn.addEventListener('click', function() {
                stopAutoPlay();
                nextSlide();
                startAutoPlay();
            });
        }

        // Start auto-play
        startAutoPlay();
        console.log('✅ Hero slider started!');
    });

    // Countdown Timer - Simple and Direct
    document.addEventListener('DOMContentLoaded', function() {
        console.log('⏰ Countdown script loaded');

        if (typeof window.bootcampTargetDate === 'undefined') {
            console.log('⚠️ No bootcamp target date set');
            return;
        }

        console.log('📅 Target date:', new Date(window.bootcampTargetDate));
        console.log('📅 Current date:', new Date());

        const targetDate = window.bootcampTargetDate;
        const countdownElement = document.getElementById('countdown-timer');

        if (!countdownElement) {
            console.error('❌ Countdown element not found');
            return;
        }

        const daysEl = document.getElementById('countdown-days');
        const hoursEl = document.getElementById('countdown-hours');
        const minutesEl = document.getElementById('countdown-minutes');
        const secondsEl = document.getElementById('countdown-seconds');

        function updateCountdown() {
            const now = new Date().getTime();
            const distance = targetDate - now;

            if (distance < 0) {
                countdownElement.innerHTML = 'কোর্স শুরু হয়ে গেছে!';
                console.log('✅ Course started!');
                return;
            }

            const days = Math.floor(distance / (1000 * 60 * 60 * 24));
            const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);

            daysEl.textContent = String(days).padStart(2, '0');
            hoursEl.textContent = String(hours).padStart(2, '0');
            minutesEl.textContent = String(minutes).padStart(2, '0');
            secondsEl.textContent = String(seconds).padStart(2, '0');

            console.log(`⏰ ${days}d ${hours}h ${minutes}m ${seconds}s`);
        }

        // Start countdown
        updateCountdown();
        setInterval(updateCountdown, 1000);
        console.log('✅ Countdown started!');
    });

    // Video Player - Simple and Direct
    document.addEventListener('DOMContentLoaded', function() {
        console.log('🎬 Video script loaded');

        const playButton = document.getElementById('play-video-button');

        if (!playButton) {
            console.log('⚠️ No play button found');
            return;
        }

        console.log('✅ Play button found!');

        playButton.onclick = function(e) {
            e.preventDefault();
            console.log('▶️ Button clicked!');

            const videoPlayer = document.getElementById('video-player');
            const videoUrl = videoPlayer ? videoPlayer.getAttribute('data-video-url') : '';

            console.log('📹 Video URL:', videoUrl);

            if (!videoUrl) {
                alert('No video URL found!');
                return;
            }

            // Extract video ID
            let videoId = '';
            if (videoUrl.includes('youtube.com/watch?v=')) {
                videoId = videoUrl.split('v=')[1].split('&')[0];
            } else if (videoUrl.includes('youtu.be/')) {
                videoId = videoUrl.split('youtu.be/')[1].split('?')[0];
            }

            console.log('🎞️ Video ID:', videoId);

            if (videoId) {
                videoPlayer.innerHTML = '<iframe width="100%" height="700px" src="https://www.youtube.com/embed/' + videoId + '?autoplay=1" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';
                console.log('✅ Video loaded!');
            } else {
                alert('Invalid YouTube URL!');
            }
        };
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.website', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/roufai/resources/views/website/home.blade.php ENDPATH**/ ?>