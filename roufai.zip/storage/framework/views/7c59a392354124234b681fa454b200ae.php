<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['course', 'enrolledCourseIds' => [], 'pendingRequestCourseIds' => []]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['course', 'enrolledCourseIds' => [], 'pendingRequestCourseIds' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $isEnrolled = in_array($course->id, $enrolledCourseIds);
    $hasPendingRequest = in_array($course->id, $pendingRequestCourseIds);
?>

<div
    class="w-full border-[1px] border-[#fff] rounded-lg lg:rounded-[21px] bg-[#232323] anim effect-card relative flex flex-col justify-between">
    <div class="w-full">
        <div class="absolute right-3 top-4 z-30 flex items-center gap-x-2">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($course->reviews_count > 0): ?>
            <p
                class="rounded-lg py-1 px-2 text-[#000] bg-orange text-xs font-normal h-5 flex justify-center items-center">
                <?php echo e($course->reviews_count); ?> রিভিউ
            </p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($course->enrollments_count > 0): ?>
            <p
                class="rounded-lg py-1 px-2 text-[#000] bg-lime text-xs font-normal h-5 flex justify-center items-center">
                <?php echo e($course->enrollments_count); ?> এনরোল
            </p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        <div class="w-full h-[220px] lg:h-[297px] relative">
            <img src="<?php echo e($course->thumbnail_url ?? asset('website-images/default-course-thumbnail.webp')); ?>"
                alt="<?php echo e($course->title); ?>"
                class="w-full rounded-t-lg lg:rounded-t-[21px] h-full object-cover">
        </div>
    </div>

    <div class="p-5 lg:p-7">
        <div class="relative z-40">
            <a href="<?php echo e(route('courses.overview', $course->slug)); ?>"
                class="font-semibold text-sm lg:text-lg leading-[140%] text-[#E2E8F0] mb-2 lg:mb-2.5 block">
                <?php echo e($course->title); ?></a>
            <p class="text-xs font-normal text-[#ababab]">
            <ul class="flex items-center gap-x-2 mt-2 lg:mt-2.5">
                <?php
                    $totalVideos = 0;
                    if($course->modules && $course->modules->count() > 0) {
                        foreach($course->modules as $module) {
                            if($module->lessons) {
                                $totalVideos += $module->lessons->count();
                            }
                        }
                    }
                ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($totalVideos > 0): ?>
                <li>
                    <span class="text-xs font-normal text-[#ababab] block">
                        🎥 <?php echo e($totalVideos); ?>টি লেসন
                    </span>
                </li>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($course->modules && $course->modules->count() > 0): ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($totalVideos > 0): ?>
                <li>
                    <span class="text-xs font-normal text-[#ababab] block">
                        |
                    </span>
                </li>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <li>
                    <span class="text-xs font-normal text-[#ababab] block">
                        📁 <?php echo e($course->modules->count()); ?>টি মডিউল
                    </span>
                </li>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?> 
            </ul>
            </p>

            <div class="flex items-center justify-between mt-3 lg:mt-5">
                <div class="w-full flex items-center gap-x-2 lg:gap-x-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($course->instructor && $course->instructor->avatar): ?>
                    <img src="<?php echo e($course->instructor->avatar); ?>" alt="<?php echo e($course->instructor->name); ?>"
                        class="w-8 h-8 lg:w-[42px] lg:h-[42px] rounded-full object-fill border border-[#fff] shrink-0">
                    <?php else: ?>
                    <img src="<?php echo e(asset('website-images/user-avatar.webp')); ?>" alt="avatar"
                        class="w-8 h-8 lg:w-[42px] lg:h-[42px] rounded-full object-fill border border-[#fff] shrink-0">
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <p class="text-xs font-normal text-[#ababab]">
                        <?php echo e($course->instructor->name ?? 'Instructor'); ?> <br>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($course->category): ?>
                        <?php echo e($course->category->name); ?>

                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </p>
                </div>
                <p class="text-xs font-normal text-[#ababab] shrink-0">
                    ⭐ <?php echo e(number_format($course->average_rating, 1)); ?>

                </p>
            </div>
        </div>

        <div class="w-full relative z-40 mt-5 flex items-center justify-between">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($course->type === 'FREE'): ?>
            <div class="mb-3 lg:mb-4">
                <span class="price-current text-[#E2E8F0] font-bold text-lg lg:text-xl">
                    ফ্রি
                </span>
            </div>
            <?php else: ?>
            <div class="flex items-center gap-x-2">
                <span class="price-current text-[#fff] font-semibold text-base lg:text-lg">৳<?php echo e(number_format($course->price)); ?></span>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <div class="flex items-center gap-x-3">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isEnrolled): ?>
                    <!-- User is enrolled - show Go to Course button -->
                    <a href="<?php echo e(route('student.course', $course->id)); ?>"
                        class="inline-flex font-golos justify-center items-center bg-green-600 border border-green-500/70 hover:bg-green-700 rounded-md lg:rounded-[10px] p-1 lg:p-1.5 px-2 lg:px-4 font-medium text-xs text-[#fff] anim transition-all duration-300">
                        কোর্সে যান →
                    </a>
                <?php elseif($hasPendingRequest): ?>
                    <!-- User has pending request - show pending status -->
                    <button disabled
                        class="inline-flex font-golos justify-center items-center bg-yellow-600/80 cursor-not-allowed rounded-md lg:rounded-[10px] p-1 lg:p-1.5 px-2 lg:px-4 font-medium text-xs text-[#fff]">
                        ⏳ প্রক্রিয়াধীন
                    </button>
                <?php else: ?>
                    <!-- Show View Details button - links to course details page -->
                    <a href="<?php echo e(route('courses.overview', $course->slug)); ?>"
                        class="inline-flex font-golos justify-center items-center bg-submit border border-[#9F93A7]/70 hover:!bg-lime rounded-md lg:rounded-[10px] p-1 lg:p-1.5 px-2 lg:px-4 font-medium text-xs text-[#fff] anim hover:text-primary group">
                        বিস্তারিত দেখুন
                    </a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/roufai/resources/views/components/course-card.blade.php ENDPATH**/ ?>