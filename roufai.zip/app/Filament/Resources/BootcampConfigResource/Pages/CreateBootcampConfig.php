<?php

namespace App\Filament\Resources\BootcampConfigResource\Pages;

use App\Filament\Resources\BootcampConfigResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBootcampConfig extends CreateRecord
{
    protected static string $resource = BootcampConfigResource::class;
}
