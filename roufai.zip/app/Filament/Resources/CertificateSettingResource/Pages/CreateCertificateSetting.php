<?php

namespace App\Filament\Resources\CertificateSettingResource\Pages;

use App\Filament\Resources\CertificateSettingResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCertificateSetting extends CreateRecord
{
    protected static string $resource = CertificateSettingResource::class;
}
